const Type = document.getElementById('Type')
const img = document.getElementById('pimg')
const pic = document.getElementById('Pictures')
const body = document.getElementById('body')

alert('EnterYourName and press Submit')
   function funct() {
         if (Type.value == 'Mariel') {
           pic.style.display = 'flex'
           body.style.backgroundImage = 'url(/Pic/1713866235039.jpg)'
           Type.value = ''
         }
         else if (Type.value == 'mariel') {
            pic.style.display = 'flex'
         }
         else if (Type.value == 'Mariel mendoza') {
            pic.style.display = 'flex'
         }
         else if (Type.value == 'mariel mendoza') {
           pic.style.display = 'flex'
         }
         else if (Type.value == 'mariel Mendoza') {
           pic.style.display = 'flex'
         }
         else if (Type.value == 'Mariel mendoza' && Type.value == 'mariel Mendoza') {
            pic.style.display = 'flex'
         }
      }